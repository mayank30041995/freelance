"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.winstonLogger = void 0;
const tslib_1 = require("tslib");
const winston_1 = tslib_1.__importDefault(require("winston"));
const elastic_apm_node_1 = tslib_1.__importDefault(require("elastic-apm-node"));
const winston_elasticsearch_1 = require("winston-elasticsearch");
const winstonLogger = (elasticsearchNode, name, level) => {
    const esTransport = new winston_elasticsearch_1.ElasticsearchTransport({
        level,
        apm: elastic_apm_node_1.default,
        clientOpts: {
            node: elasticsearchNode,
            maxRetries: 2,
            requestTimeout: 10000,
            sniffOnStart: false,
        },
    });
    return winston_1.default.createLogger({
        exitOnError: false,
        defaultMeta: {
            service: name,
        },
        transports: [
            new winston_1.default.transports.Console({
                level,
                handleExceptions: true,
                format: winston_1.default.format.combine(winston_1.default.format.colorize(), winston_1.default.format.simple()),
            }),
            esTransport,
        ],
    });
};
exports.winstonLogger = winstonLogger;
//# sourceMappingURL=logger.js.map