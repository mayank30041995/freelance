"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyGatewayRequest = verifyGatewayRequest;
const tslib_1 = require("tslib");
const jsonwebtoken_1 = tslib_1.__importDefault(require("jsonwebtoken"));
const error_handler_1 = require("./error-handler");
const tokens = [
    'auth',
    'seller',
    'gig',
    'search',
    'buyer',
    'message',
    'order',
    'review',
];
function verifyGatewayRequest(req, _res, next) {
    var _a, _b;
    if (!((_a = req.headers) === null || _a === void 0 ? void 0 : _a.gatewaytoken)) {
        throw new error_handler_1.NotAuthorizedError('Invalid request', 'verifyGatewayRequest() method: Request not coming from api gateway');
    }
    const token = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.gatewaytoken;
    if (!token) {
        throw new error_handler_1.NotAuthorizedError('Invalid request', 'verifyGatewayRequest() method: Request not coming from api gateway');
    }
    try {
        const payload = jsonwebtoken_1.default.verify(token, '1282722b942e08c8a6cb033aa6ce850e');
        if (!tokens.includes(payload.id)) {
            throw new error_handler_1.NotAuthorizedError('Invalid request', 'verifyGatewayRequest() method: Request payload is invalid');
        }
    }
    catch (error) {
        throw new error_handler_1.NotAuthorizedError('Invalid request', 'verifyGatewayRequest() method: Request not coming from api gateway');
    }
    next();
}
//# sourceMappingURL=gateway-middleware.js.map