import { Logger, LoggerOptions } from 'winston';
export declare const winstonLogger: (elasticsearchNode: string, name: string, level: LoggerOptions["level"]) => Logger;
